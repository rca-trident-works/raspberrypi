# coding: utf-8

# リストを定義する
animals = ["dog", "cat", "penguin", "mouse", "bird"]

# for文で要素を順番に出力する
for a in animals:
    print(a)
