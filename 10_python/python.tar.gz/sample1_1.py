# coding: utf-8

print("Pythonでメッセージを")
print("表示させます")
