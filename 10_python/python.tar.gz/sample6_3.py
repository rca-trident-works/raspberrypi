# coding: utf-8

# 処理を10回繰り返す
for i in range(10):
    print(i)
