# coding: utf-8

print("私は")
print("Pythonを")
print("学習します")
