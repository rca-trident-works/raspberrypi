# coding: utf-8

i = 0

# 処理を5回繰り返す
while i < 5:
    print("メッセージの出力")
    i += 1 # 繰り返しの度に変数iを1ずつ加算する
