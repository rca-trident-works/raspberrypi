# coding: utf-8

a = 6

# 変数aが10以上であればTru
if a >= 10:
    print("if文の条件を満たしています")
elif a < 6:
    print("elif文の条件を満たしています")
else:
    print("else文の処理が実行されます")

print("処理が終了しました")
