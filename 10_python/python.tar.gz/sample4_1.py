# cofing: utf-8

data = input("キーボードで何か入力し、エンターキーを押してください:")

print("入力されたものは" + data + "です")
