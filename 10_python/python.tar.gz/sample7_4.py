# coding: utf-8

# add関数を定義する
# 2つの引数を足し算した結果を戻り値とする
def add(a, b):
    x = a + b
    return x

result = add(10, 20)

print(result)
