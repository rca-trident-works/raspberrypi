# coding: utf-8

# 引数として受け取った10はカッコ内の変数aに代入される
def func(a):
    print("引数である変数aの値は" + str(a))


# func関数の引数に「10」の値を送る
func(10)
