# coding: utf-8

def show():
    print("show関数が呼び出されました")
    print("このようにshow関数の中に記述したコードが実行されます")

# show関数を複数回呼び出す
show()
show()
show()
