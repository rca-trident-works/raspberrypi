# coding: utf-8

# おはようと出力する
# print("おはよう")
# こんにちはと出力する
print("こんにちは")
